/* --- REFINED INTERACTIVE CSS LOGIC --- */

document.addEventListener('DOMContentLoaded', () => {

    /* --- STICKY NAVBAR BACKGROUND --- */
    const navbar = document.getElementById('navbar');

    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    /* --- HERO SLIDER --- */
    const slides = document.querySelectorAll('.slide');
    let currentSlide = 0;
    const slideInterval = 5000; // 5 seconds per slide

    function nextSlide() {
        slides[currentSlide].classList.remove('active');
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }

    if (slides.length > 0) {
        setInterval(nextSlide, slideInterval);
    }

    /* --- SCROLL REVEAL ANIMATION --- */
    const revealElements = document.querySelectorAll('.reveal');

    const revealCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                // Optional: stop observing once animated
                // observer.unobserve(entry.target); 
            }
        });
    };

    const revealOptions = {
        threshold: 0.1, // 10% of element visible
        rootMargin: "0px 0px -50px 0px" // Trigger slightly before it comes fully into view
    };

    const revealObserver = new IntersectionObserver(revealCallback, revealOptions);

    revealElements.forEach(el => revealObserver.observe(el));

    // For hero content initial reveal (fade + soft 20px upward motion, staggered)
    setTimeout(() => {
        document.querySelectorAll('.hero .reveal-item').forEach((el, index) => {
            el.style.opacity = "0";
            el.style.transform = "translateY(20px)";
            // Use 500-800ms timeline depending on stagger for professional polish
            el.style.transition = `all 0.6s cubic-bezier(0.2, 0.8, 0.2, 1) ${index * 0.15}s`;

            setTimeout(() => {
                el.style.opacity = "1";
                el.style.transform = "translateY(0)";
            }, 50);
        });
    }, 50);

    /* --- TESTIMONIAL CAROUSEL --- */
    const track = document.getElementById('carouselTrack');
    if (track) {
        const slidesCarousel = Array.from(track.children);
        const indicatorsContainer = document.getElementById('carouselIndicators');

        if (slidesCarousel.length > 0) {
            let currentCarouselIndex = 0;
            const carouselInterval = 4500; // 4.5 seconds
            let carouselTimer;

            // Create indicators dynamically based on number of slides
            slidesCarousel.forEach((_, index) => {
                const dot = document.createElement('button');
                dot.classList.add('indicator');
                if (index === 0) dot.classList.add('active');
                dot.setAttribute('aria-label', `Go to slide ${index + 1}`);
                dot.addEventListener('click', () => {
                    goToCarouselSlide(index);
                    resetCarouselTimer();
                });
                indicatorsContainer.appendChild(dot);
            });

            const indicators = Array.from(indicatorsContainer.children);

            function goToCarouselSlide(index) {
                track.style.transform = `translateX(-${index * 100}%)`;
                indicators.forEach(ind => ind.classList.remove('active'));
                indicators[index].classList.add('active');
                currentCarouselIndex = index;
            }

            function nextCarouselSlide() {
                let nextIndex = (currentCarouselIndex + 1) % slidesCarousel.length;
                goToCarouselSlide(nextIndex);
            }

            function startCarouselTimer() {
                carouselTimer = setInterval(nextCarouselSlide, carouselInterval);
            }

            function stopCarouselTimer() {
                clearInterval(carouselTimer);
            }

            function resetCarouselTimer() {
                stopCarouselTimer();
                startCarouselTimer();
            }

            // Start auto-play
            startCarouselTimer();

            // Pause on hover
            const carouselContainer = document.querySelector('.carousel-container');
            if (carouselContainer) {
                carouselContainer.addEventListener('mouseenter', stopCarouselTimer);
                carouselContainer.addEventListener('mouseleave', startCarouselTimer);
            }
        }
    }

    /* --- SMOOTH SCROLLING FOR ANCHOR LINKS --- */
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                const offset = 80; // offset for sticky navbar
                const bodyRect = document.body.getBoundingClientRect().top;
                const elementRect = targetElement.getBoundingClientRect().top;
                const elementPosition = elementRect - bodyRect;
                const offsetPosition = elementPosition - offset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    /* --- SUBTLE PARALLAX HERO BACKGROUND --- */
    const heroSection = document.getElementById('hero');
    const heroSlider = document.querySelector('.hero-slider');
    if (heroSection && heroSlider) {
        window.addEventListener('scroll', () => {
            // requestAnimationFrame for performance
            requestAnimationFrame(() => {
                const scroll = window.scrollY;
                if (scroll < window.innerHeight) {
                    heroSlider.style.transform = `translateY(${scroll * 0.2}px)`;
                }
            });
        });
    }

});

/* --- FAQ ACCORDION --- */
function toggleFaq(btn) {
    const item = btn.closest('.faq-item');
    const isOpen = item.classList.contains('open');
    // Close all open items
    document.querySelectorAll('.faq-item.open').forEach(el => el.classList.remove('open'));
    // Open the clicked one if it was closed
    if (!isOpen) item.classList.add('open');
}

/* --- JOB LISTING ACCORDION --- */
function toggleJob(btn) {
    const card = btn.closest('.job-card');
    const isOpen = card.classList.contains('open');
    // Close all
    document.querySelectorAll('.job-card.open').forEach(el => el.classList.remove('open'));
    // Open clicked if it was closed
    if (!isOpen) card.classList.add('open');
}

/* =============================================
   HAMBURGER MENU
   ============================================= */
(function () {
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');
    if (!hamburger || !navLinks) return;

    hamburger.addEventListener('click', () => {
        const isOpen = hamburger.classList.toggle('open');
        navLinks.classList.toggle('open', isOpen);
        hamburger.setAttribute('aria-expanded', isOpen);
    });

    // Close menu when any nav link is clicked
    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('open');
            navLinks.classList.remove('open');
            hamburger.setAttribute('aria-expanded', false);
        });
    });

    // Close when clicking outside
    document.addEventListener('click', (e) => {
        if (!hamburger.contains(e.target) && !navLinks.contains(e.target)) {
            hamburger.classList.remove('open');
            navLinks.classList.remove('open');
            hamburger.setAttribute('aria-expanded', false);
        }
    });
})();

/* =============================================
   ANIMATED STATS COUNTER
   ============================================= */
(function () {
    const statsBar = document.querySelector('.stats-bar');
    if (!statsBar) return;

    function animateCounter(el) {
        const target = parseInt(el.getAttribute('data-target'), 10);
        const duration = 1800;
        const start = performance.now();

        function update(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            // ease-out cubic
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = Math.floor(eased * target);
            if (progress < 1) requestAnimationFrame(update);
            else el.textContent = target;
        }
        requestAnimationFrame(update);
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                document.querySelectorAll('.stat-number').forEach(animateCounter);
                observer.disconnect();
            }
        });
    }, { threshold: 0.4 });

    observer.observe(statsBar);
})();

/* =============================================
   SCROLL-TO-TOP BUTTON
   ============================================= */
(function () {
    const btn = document.getElementById('scrollTopBtn');
    if (!btn) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 320) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    }, { passive: true });

    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
})();
